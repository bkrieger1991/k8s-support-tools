# Json Validator for ConfigMaps
First of all, thank you for downloading this tool.


## Usage as global tool
> TBD

## Usage as pre-commit hook
> TBD